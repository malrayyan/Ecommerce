package com.madisonisland.helper;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.madisonisland.listeners.WebDriverListener;
import com.madisonisland.pages.HomePage;

public class TestBase extends BaseProperties
{
    private static Logger Log = Logger.getLogger(TestBase.class);
    private WebDriver basedriver;
    public WebDriver driver;
    protected HomePage homepage;
    private static final String ESCAPE_PROPERTY = "org.uncommons.reportng.escape-output";
  
  @Parameters({"browser", "url"})
  @BeforeClass
  public void createDriver(String browser, String url) {
	  //readProperties();
	  System.setProperty(ESCAPE_PROPERTY, "false");
	  if(browser.toLowerCase().contains("chrome"))
	  {
		  ChromeOptions options=new ChromeOptions();
		  options.addArguments("disable-infobars");
		  options.setCapability("CapabilityType.ACCEPT_SSL_CERTS", true);
		  System.setProperty("webdriver.chrome.driver", "src/main/resources/driver/chromedriver.exe");
		  basedriver = new ChromeDriver(options);
	  }
	  else if(browser.toLowerCase().contains("firefox"))
	  {
		  FirefoxOptions options = new FirefoxOptions();
		  options.setAcceptInsecureCerts(true);
		  DesiredCapabilities cap=new DesiredCapabilities();
		  cap.setCapability(CapabilityType.HAS_NATIVE_EVENTS, false);
		  cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		  System.setProperty("webdriver.gecko.driver", "src/main/resources/driver/geckodriver.exe");
		  basedriver = new FirefoxDriver(options);
	  }
	  else if(browser.toLowerCase().contains("ie"))
	  {
		  DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		  capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		  capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		  System.setProperty("webdriver.ie.driver", "src/main/resources/driver/IEDriverServer.exe");
		  basedriver = new InternetExplorerDriver(capabilities);
	  }
	  
	  EventFiringWebDriver efwd=new EventFiringWebDriver(basedriver);
	  WebDriverListener eventListener=new WebDriverListener(basedriver);
	  efwd.register(eventListener);
	  driver=efwd;
	  
	  driver.manage().window().maximize();
	  driver.manage().deleteAllCookies();
	  Log.info("Opening the Url - "+ url);
	  driver.get(url);
  }
  
  public WebDriver getDriver()
  {
	  return driver;
  }
  
  @AfterClass()
  public void quitDriver() {
	  if(driver!=null)
	  {
		  try
		  {
			  driver.close();
		  }
		  catch(WebDriverException e)
		  {
			  System.out.println("**********CAUGHT EXCEPTION IN DRIVER TEAR DOWN**********");
			  System.out.println(e);
		  }
	  }
  }
}