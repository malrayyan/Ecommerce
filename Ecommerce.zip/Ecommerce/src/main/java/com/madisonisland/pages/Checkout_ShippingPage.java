package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class Checkout_ShippingPage extends UtilClass{

	private static Logger Log = Logger.getLogger(Checkout_ShippingPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(xpath = "//input[@id='s_method_ups_3DS']")
    private WebElement threeDaySelect;
	
	@FindBy(xpath = "//div[@id='shipping-method-buttons-container']/button")
    private WebElement btnContinue;
	
	@FindBy(xpath = "//span[@id='shipping-method-please-wait']/img")
    private WebElement loadingIcon;
	
	//Constructor
	public Checkout_ShippingPage(WebDriver driver) {
		Log.info("Checkout-Shipping Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 90);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Checkout"));
		wait.until(ExpectedConditions.visibilityOf(btnContinue));
	}
	
	
	public Checkout_ShippingPage choose3DaySelect() {
		clickElement(driver, threeDaySelect);
		Log.info("Clicked 3 day select option");

		return this;
	}
	
	public Checkout_PaymentPage clickContinue() {
		clickElement(driver, btnContinue);
		Log.info("Clicked Continue button");
		wait.until(ExpectedConditions.invisibilityOf(loadingIcon));

		return new Checkout_PaymentPage(driver);
	}
}