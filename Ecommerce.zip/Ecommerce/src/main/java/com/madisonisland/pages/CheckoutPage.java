package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class CheckoutPage extends UtilClass{

	private static Logger Log = Logger.getLogger(CheckoutPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(xpath = "//input[@id='login:guest']")
    private WebElement radioGuestCheckout;
	
	@FindBy(xpath = "//button[@id='onepage-guest-register-button']")
    private WebElement btnContinue;
	
	//Constructor
	public CheckoutPage(WebDriver driver) {
		Log.info("Checkout Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 60);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Checkout"));
		wait.until(ExpectedConditions.visibilityOf(btnContinue));
	}
	
	public CheckoutPage clickCheckOutAsGuest() {
		clickElement(driver, radioGuestCheckout);
		Log.info("Clicked Check out as Guest radio button");

		return this;
	}
	
	public Checkout_BillingPage clickContinue() {
		clickElement(driver, btnContinue);
		Log.info("Clicked Continue button");

		return new Checkout_BillingPage(driver);
	}
}