package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class ProductPage extends UtilClass{

	private static Logger Log = Logger.getLogger(ProductPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(id = "qty")
    private WebElement txtQuantity;
	
	@FindBy(xpath = "//div[@class='add-to-cart-buttons']//span[text()='Add to Cart']")
    private WebElement btnAddToCart;
	
	//By imgLoading = By.xpath("//div[contains(@class,'LoadingIndicator')]");
	
	
	//Constructor
	public ProductPage(WebDriver driver) {
		Log.info("Product Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 60);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.visibilityOf(btnAddToCart));
	}
	
	public boolean isProductAvailableandInStock(String product) {
		By inStockXpath = By.xpath("//div[@class='product-name']/span[.='"+ product +"']/following::p[@class='availability in-stock']/span[text()='In stock']");

		return isAtleastOneElementDisplayed(driver, inStockXpath);
	}
	
	//Pink, Red, Royal Blue, White
	public ProductPage selectColor(String color) {
		By colorXpath = By.xpath("//ul[contains(@id,'color')]/li/a[@title='"+ color +"']");
		clickElementByLocator(driver, colorXpath);
		Log.info("Selected Color : "+color);

		return this;
	}

	//XS, S, M, L, XL
	public ProductPage selectSize(String size) {
		By sizeXpath = By.xpath("//ul[contains(@id,'size')]/li/a[@title='"+ size +"']");
		clickElementByLocator(driver, sizeXpath);
		Log.info("Selected Size : "+size);

		return this;
	}
	
	public ProductPage setQuantity(String qty) {
		setText(driver, txtQuantity, qty);
		Log.info("Set Quantity : "+qty);

		return this;
	}	
	
	public ShoppingCartPage clickAddToCart() {
		clickElement(driver, btnAddToCart);
		Log.info("Clicked Add to Cart Button");

		return new ShoppingCartPage(driver);
	}
}