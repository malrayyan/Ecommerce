package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class Checkout_OrderReviewPage extends UtilClass{

	private static Logger Log = Logger.getLogger(Checkout_OrderReviewPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(xpath = "//button//span[text()='Place Order']")
    private WebElement btnPlaceOrder;
	
	@FindBy(xpath = "//tr[@class='last']//span[@class='price']")
    private WebElement grandTotal;
	
	@FindBy(xpath = "//span[@id='review-please-wait']/img")
    private WebElement loadingIcon;
	
	//Constructor
	public Checkout_OrderReviewPage(WebDriver driver) {
		Log.info("Checkout-Order Review Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 90);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Checkout"));
		wait.until(ExpectedConditions.visibilityOf(btnPlaceOrder));
	}
	
	
	public String getGrandTotal() {
		Log.info("Grand Total is : "+grandTotal.getText());
		return grandTotal.getText();
	}
	
	public OrderConfirmationPage clickPlaceOrder() {
		clickElement(driver, btnPlaceOrder);
		Log.info("Clicked Place Order button");
		//wait.until(ExpectedConditions.invisibilityOf(loadingIcon));

		return new OrderConfirmationPage(driver);
	}
	
	
}