package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class Checkout_PaymentPage extends UtilClass{

	private static Logger Log = Logger.getLogger(Checkout_PaymentPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	
	@FindBy(xpath = "//div[@id='payment-buttons-container']/button")
    private WebElement btnContinue;
	
	@FindBy(xpath = "//span[@id='payment-please-wait']/img")
    private WebElement loadingIcon;
	
	//Constructor
	public Checkout_PaymentPage(WebDriver driver) {
		Log.info("Checkout-Payment Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 120);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Checkout"));
		wait.until(ExpectedConditions.visibilityOf(btnContinue));
	}
	
	public Checkout_OrderReviewPage clickContinue() {
		clickElement(driver, btnContinue);
		Log.info("Clicked Continue button");
		wait.until(ExpectedConditions.invisibilityOf(loadingIcon));

		return new Checkout_OrderReviewPage(driver);
	}
}