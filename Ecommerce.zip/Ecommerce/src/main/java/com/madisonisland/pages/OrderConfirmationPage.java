package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class OrderConfirmationPage extends UtilClass{

	private static Logger Log = Logger.getLogger(OrderConfirmationPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(xpath = "//h1[text()='Your order has been received.']")
    private WebElement txtOrderReceived;
	
	@FindBy(xpath = "//div[@class='page-title']/following-sibling::p[1]")
    private WebElement txtOrderId;
	
	//Constructor
	public OrderConfirmationPage(WebDriver driver) {
		Log.info("Order Confirmation Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 90);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Magento"));
		wait.until(ExpectedConditions.visibilityOf(txtOrderReceived));
	}
	
	
	public int getOrderId() {
		String order = txtOrderId.getText();
		Log.info("Order is placed : "+order);
		String orderId = order.split(":")[1].split("\\.")[0].trim();
		Log.info("OrderId is  : "+order);
		return Integer.valueOf(orderId);
	}
}