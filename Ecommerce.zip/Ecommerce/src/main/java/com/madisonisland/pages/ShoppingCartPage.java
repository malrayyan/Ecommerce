package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class ShoppingCartPage extends UtilClass{

	private static Logger Log = Logger.getLogger(ShoppingCartPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(xpath = "//button/span/span[text()='Proceed to Checkout']")
    private WebElement btnProceedToCheckOut;
	
	//By imgLoading = By.xpath("//div[contains(@class,'LoadingIndicator')]");
	
	
	//Constructor
	public ShoppingCartPage(WebDriver driver) {
		Log.info("Shopping Cart Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 60);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Shopping Cart"));
		wait.until(ExpectedConditions.visibilityOf(btnProceedToCheckOut));
	}
	
	public CheckoutPage clickProceedToCheckOut() {
		clickElement(driver, btnProceedToCheckOut);
		Log.info("Clicked Proceed to Check Out Button");

		return new CheckoutPage(driver);
	}
}