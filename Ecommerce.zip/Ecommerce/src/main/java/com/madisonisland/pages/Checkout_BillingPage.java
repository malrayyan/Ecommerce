package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.madisonisland.helper.UtilClass;

public class Checkout_BillingPage extends UtilClass{

	private static Logger Log = Logger.getLogger(Checkout_BillingPage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	@FindBy(xpath = "//input[@id='billing:firstname']")
    private WebElement txtFirstName;
	
	@FindBy(xpath = "//input[@id='billing:lastname']")
    private WebElement txtLastName;
	
	@FindBy(xpath = "//input[@id='billing:email']")
    private WebElement txtEmailAddress;	
	
	@FindBy(xpath = "//input[@id='billing:street1']")
    private WebElement txtAddress;	
	
	@FindBy(xpath = "//input[@id='billing:city']")
    private WebElement txtCity;
	
	@FindBy(xpath = "//select[@id='billing:region_id']")
    private WebElement ddlState;	

	@FindBy(xpath = "//input[@id='billing:postcode']")
    private WebElement txtZip;
	
	@FindBy(xpath = "//select[@id='billing:country_id']")
    private WebElement ddlCountry;	
	
	@FindBy(xpath = "//input[@id='billing:telephone']")
    private WebElement txtTelephone;
	
	@FindBy(xpath = "//input[@id='billing:use_for_shipping_yes']")
    private WebElement radioShipToThisAddress;
	
	@FindBy(xpath = "//div[@id='billing-buttons-container']/button")
    private WebElement btnContinue;
	
	@FindBy(xpath = "//span[@id='billing-please-wait']/img")
    private WebElement loadingIcon;
	
	//Constructor
	public Checkout_BillingPage(WebDriver driver) {
		Log.info("Checkout-Billing Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 240);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Checkout"));
		wait.until(ExpectedConditions.visibilityOf(btnContinue));
	}
	
	
	public Checkout_BillingPage setFirstName(String firstname) {
		setText(driver, txtFirstName, firstname);
		Log.info("Entered First Name : "+firstname);

		return this;
	}
	
	public Checkout_BillingPage setLastName(String lastname) {
		setText(driver, txtLastName, lastname);
		Log.info("Entered Last Name : "+lastname);

		return this;
	}
	
	public Checkout_BillingPage setEmailAddress(String email) {
		setText(driver, txtEmailAddress, email);
		Log.info("Entered Email Address : "+email);

		return this;
	}
	
	public Checkout_BillingPage setAddress(String address) {
		setText(driver, txtAddress, address);
		Log.info("Entered Address : "+address);

		return this;
	}
	
	public Checkout_BillingPage setCity(String city) {
		setText(driver, txtCity, city);
		Log.info("Entered City : "+city);

		return this;
	}
	
	public Checkout_BillingPage selectState(String state) {
		selectByValue(driver, ddlState, state);
		Log.info("Selected State : "+state);

		return this;
	}
	
	public Checkout_BillingPage setZipCode(String zip) {
		setText(driver, txtZip, zip);
		Log.info("Entered Zip : "+zip);

		return this;
	}
	
	public Checkout_BillingPage selectCountry(String country) {
		selectByValue(driver, ddlCountry, country);
		Log.info("Selected Country : "+country);

		return this;
	}
	
	public Checkout_BillingPage setTelephone(String telephone) {
		setText(driver, txtTelephone, telephone);
		Log.info("Entered Telephone : "+telephone);

		return this;
	}
	
	public Checkout_BillingPage clickShipToThisAddress() {
		clickElement(driver, radioShipToThisAddress);
		Log.info("Clicked Ship to This Address radio button");

		return this;
	}
	
	public Checkout_ShippingPage clickContinue() {
		clickElement(driver, btnContinue);
		Log.info("Clicked Continue button");
		wait.until(ExpectedConditions.invisibilityOf(loadingIcon));

		return new Checkout_ShippingPage(driver);
	}
}