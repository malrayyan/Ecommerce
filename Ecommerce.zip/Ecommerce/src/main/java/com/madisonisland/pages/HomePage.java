package com.madisonisland.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.madisonisland.helper.UtilClass;

public class HomePage extends UtilClass{
	
    private static Logger Log = Logger.getLogger(HomePage.class);
	private WebDriver driver;
	private WebDriverWait wait;
	
	
	@FindBy(xpath = "//a/span[text()='Account']")
    private WebElement lnkAccount;
	
	@FindBy(xpath = "//img[@alt='Madison Island']")
    private WebElement lnkHome;
	
	//Constructor
	public HomePage(WebDriver driver)
	{
		Log.info("Home Page constructor is Invoked");
		this.driver = driver;
		wait = new WebDriverWait(driver, 60);
		PageFactory.initElements(driver, this);
		wait.until(ExpectedConditions.titleContains("Madison Island"));
		wait.until(ExpectedConditions.visibilityOf(lnkAccount));
	}
	
	public ProductPage clickProduct(String productname)
	{
		By prodXpath = By.xpath("//a[text()='"+ productname +"']");
		clickElementByLocator(driver, prodXpath);
		Log.info("Clicked on the Product : "+productname);
		
		return new ProductPage(driver);
	}
	
	
	public HomePage clickHome()
	{
		clickElement(driver, lnkHome);
		Log.info("Clicked on the Home Icon.");
		
		return new HomePage(driver);
	}
}