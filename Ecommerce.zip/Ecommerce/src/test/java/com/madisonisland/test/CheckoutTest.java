package com.madisonisland.test;

import static org.testng.AssertJUnit.assertTrue;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.madisonisland.helper.TestBase;
import com.madisonisland.helper.UtilClass;
import com.madisonisland.pages.Checkout_BillingPage;
import com.madisonisland.pages.Checkout_OrderReviewPage;
import com.madisonisland.pages.Checkout_PaymentPage;
import com.madisonisland.pages.Checkout_ShippingPage;
import com.madisonisland.pages.HomePage;
import com.madisonisland.pages.OrderConfirmationPage;
import com.madisonisland.pages.ProductPage;
import com.madisonisland.pages.ShoppingCartPage;

public class CheckoutTest extends TestBase{
	
	public HomePage homePage;
	public ProductPage productPage;
	public ShoppingCartPage shoppingcartPage;
	public Checkout_BillingPage billingpage;
	public Checkout_ShippingPage shippingPage;
	public Checkout_PaymentPage paymentPage;
	public Checkout_OrderReviewPage orderreviewPage;
	public OrderConfirmationPage orderconfirmPage;
	
	@DataProvider(name = "ValidSearch")
    public Object[][] validSearchTestData() throws Exception{
         Object[][] testObjArray = UtilClass.getTableArray(System.getProperty("user.dir")+"\\src\\test\\resources\\Testdata\\TestData.xlsx", "ValidSearch");
         return (testObjArray);
	}
	
	@BeforeClass
	public void setup()
	{
		homepage=new HomePage(driver);
	}
	
	@BeforeMethod
	public void clickhome()
	{
		homepage.clickHome();
	}

	@Test(priority = 1, dataProvider="ValidSearch")
	public void validSearch(String product, String color, String Size, String Quantity, String firstname,
			String lastname, String email, String address, String city, String state, String zip, String country,
			String telephone, String totalamount) throws Exception {
		productPage = homepage.clickProduct(product);
		assertTrue("Product is Out of Stock", productPage.isProductAvailableandInStock(product));

		shoppingcartPage = productPage.selectColor(color).selectSize(Size).setQuantity(Quantity).clickAddToCart();
		billingpage = shoppingcartPage.clickProceedToCheckOut().clickCheckOutAsGuest().clickContinue();
		billingpage.setFirstName(firstname).setLastName(lastname).setEmailAddress(email).setAddress(address).setCity(city)
					.selectState(state).setZipCode(zip).selectCountry(country).setTelephone(telephone);
		shippingPage = billingpage.clickShipToThisAddress().clickContinue();
		paymentPage = shippingPage.choose3DaySelect().clickContinue();
		orderreviewPage = paymentPage.clickContinue();
		assertTrue("Grand Total not matched. Expected = "+ totalamount +". But Actual is " + 
					orderreviewPage.getGrandTotal() , orderreviewPage.getGrandTotal().equals(totalamount));
		orderconfirmPage = orderreviewPage.clickPlaceOrder();
		assertTrue("Order number is not greater than 145000001.", orderconfirmPage.getOrderId() > 145000001);
	}
}